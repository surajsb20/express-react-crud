import { createStore } from "redux"
import CombineReducers from "../Combinereducer/CombineReducer"

const Store=createStore(CombineReducers)
export default Store;